tellraw @a [{"text":"[Limpeza] ","color":"gold"},{"text":"Itens no chao serao removidos em 30 segundos!","color":"yellow"}]
playsound minecraft:block.note_block.pling master @a
schedule function tno_itemcleaner:cleanup 30s replace

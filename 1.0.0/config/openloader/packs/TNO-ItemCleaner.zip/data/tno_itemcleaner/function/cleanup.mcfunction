kill @e[type=minecraft:item]
kill @e[type=minecraft:experience_orb]
tellraw @a [{"text":"[Limpeza] ","color":"gold"},{"text":"Itens no chao removidos.","color":"green"}]
schedule function tno_itemcleaner:warn 9m30s replace
